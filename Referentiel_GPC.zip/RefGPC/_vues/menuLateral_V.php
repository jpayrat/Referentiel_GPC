<h1>je recherche ...</h1>
<ul>
    <!--<li><a href="#" id="lienCarto">Cartographie</a></li>-->
    <li class="<?= $classLienMenuLateralIlot; ?>"><a href="ilot" id="lienIlot">Ilots</a></li>
    <li class="<?= $classLienMenuLateralCentre; ?>"><a href="centre" id="lienCentre">Centres</a></li>
    <li class="<?= $classLienMenuLateralTech; ?>"><a href="tech" id="lienTech">Techniciens</a></li>
    <!--<li><a href="#" id="lienActProd">Activité / produit</a></li>

    <li><a href="#" id="lienAigFin">Aiguillage E/RS</a></li>-->
</ul>