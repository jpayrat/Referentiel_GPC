</div><!-- fin du .corps -->

<div class="footer">
	<div class="footer_content">

		<div class="footer_left">Interne Groupe France T&eacute;l&eacute;com</div>
		<div class="footer_middle"><a href="mailto:julien.payrat@orange.com;marc.ponchon@orange.com" class="orange">Contact</a></div>
		<div class="footer_right">Copyright © 2016 ~ PAYRAT Julien / PONCHON Marc</div>	</div><!-- fin du pied de page //-->

	</div>
</div>

</body>
</html>