<?php

$chemin = '../';