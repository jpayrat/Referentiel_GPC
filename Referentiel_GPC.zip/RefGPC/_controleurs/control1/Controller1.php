<?php
namespace RefGPC\_controleurs;


class ControllerIndex
{
	function __construct() {
		echo '<br> construct ControllerIndex';
	}
}