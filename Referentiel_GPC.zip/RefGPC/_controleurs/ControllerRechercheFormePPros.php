<?php

echo 'recherche par forme';