<?php
//Controllers
namespace RefGPC\_systemClass;

use \RefGPC\_controleurs\ControllerIndex;
use \RefGPC\_systemClass\Autoloader;

class Controllers
{
	// controller par defaut
	static $defaultController = 'RefGPC\_controleurs\ControllerIndex';
		
	static function createController($name) {	

		$controllerName = 'RefGPC\_controleurs\Controller'.ucfirst(strtolower ($name));
		echo '<br>createController : ['.$controllerName .']';
		$pathToControler = Autoloader::createClassPath($controllerName);
		if (file_exists($pathToControler)) {
			return new $controllerName;
		}
		echo '<br><font color ="red">createController Erreur : ['.$controllerName .'] chemin inexistant : ['.$pathToControler.'] </font>';
		return new self::$defaultController;
		//return null;
	}

	
}