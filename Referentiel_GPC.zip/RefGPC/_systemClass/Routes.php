<?php
namespace RefGPC\_systemClass;
/*
donne le chemin vers le controleur
*/
use \RefGPC\_systemClass\Autoloader;

class Routes
{


	
	/**
	 * retrouve le nom du controller, l'action  et les parametres
	 * � partir de l'url r�cup�re de index
	 * Ctrl/action/param1/param2
	 */
	static function getParamUri($url) {
		$param = explode("/",$url);
		var_dump($param);
		if (count($param)<2) {
			return  array( 'ControllerIndex', 'Index'); // controller par defaut, action par defaut
		}
		// teste validite controller
		$pathToController = Autoloader::createClassPath($param[0]);
		if (file_exists($pathToController)) {
			echo '<br><font color ="red">createClassPath Erreur : ['.$param[0] .'] chemin inexistant : ['.$pathToController.'] </font>';
			return  array( 'ControllerIndex', 'Index'); // controller par defaut, action par defaut
		}
		return $param;
	}
	
}