<?php
namespace RefGPC\_systemClass;

/**
 * charge les classes et les instancie
 */
class Autoloader{
	const TAG = 'RefGPC';
	
    static function register(){
		echo '<br>register:: ['.__CLASS__.'] , "autoload"';
        spl_autoload_register(array(__CLASS__, 'autoload'));
    }

	/**
	 * fait le lien entre le namespace de la class et son chemin physique
	 * @param	string $class Class name (with entire namespace)
	 */
    static function autoload($className){
		echo '<br>->Autoloader:: autoload ['.$className.']';
		$path = self::createClassPath($className);
		if ($path != null ) {
			require $path;
			return;
		}
		echo '<br>autoload:: Erreur ['.$className.'] pas de chargement';
    }
	
	static function createClassPath($className) {
		echo '<br>->Autoloader:: createClassPath:: className ['.$className.'] :  dir ['.__DIR__.']';
		$path = null;
		if(strpos($className, Autoloader::TAG.'\\') !== 0) return $path;
		$relative_NS = str_replace(Autoloader::TAG, '', $className); // supprime TAG
		$relative_NS = str_replace('\\', '/', $relative_NS);  // remplace les \ par des /
		//$relative_NS = trim($relative_NS, '/');  // 
		$path = self::TAG.$relative_NS.'.php';
		echo '<br>path ['.$path.']';
		return $path;
	}	

}