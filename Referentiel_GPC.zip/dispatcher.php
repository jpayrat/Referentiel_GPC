<?php
// Autoloader de classes
require("RefGPC/_systemClass/Autoloader.php");
use \RefGPC\_systemClass\Autoloader;
use \RefGPC\_systemClass\Controllers;
use RefGPC\_systemClass\Routes;

Autoloader::register();

// Definition des chemins
define ('WEBPATH', str_replace('dispatcher.php', '', $_SERVER['SCRIPT_NAME']));
define ('PATH', str_replace('dispatcher.php', '', $_SERVER['SCRIPT_FILENAME']));
echo '<br> PATH ['.PATH.']';

//Controllers::readControllers();



// Définition des dossiers du MVC
$dirControleurs = PATH.'_controleurs/';
$dirModels = PATH.'_models/';
$dirVues = PATH.'_vues/';

// Récupération de la page demandée par l'utilisateur
$pageAsk = htmlentities($_GET['url']);

// Opérations sur la session


echo '<br> pageAsk ['.$pageAsk.']';
$param = Routes::getParamUri($pageAsk);
// $ctrl = $param[0];
// $method = $param[1];

// Appels des controleurs
$controller = Controllers::createController($param[0]);

/*

$path = Routes::createClassPath($pageAsk);



if ($path == null ) {
	echo '<br>path null !';
	$controller = Controllers::createController('index');
}
else {
	echo '<br>path ['.$path.']';
}
/*
switch ($pageAsk)
{
    case "ilotAffForm";
        require($dirControleurs."ilotAffForm_C.php");
    break;

    case "ilotResForm";
        echo 'plop'; require($dirControleurs."rechercheFormePPros_C.php");
    break;

    default : 
		//RefGPC\Autoloader::echoClassesRegistered();
		echo '<br>pageAsk:: default = '.$dirControleurs."ilotAffForm_C.php";
		
		//require($dirControleurs."ilotAffForm_C.php"); // Page index par defaut
		
}
*/